import json

def cargar_json(nombre_archivo):
    """Lee un archivo JSON y devuelve su contenido. Si no existe, retorna una lista vacía."""
    try:
        with open(nombre_archivo, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

def guardar_json(nombre_archivo, datos):
    """Escribe los datos de la memoria en el archivo JSON especificado."""
    with open(nombre_archivo, 'w', encoding='utf-8') as f:
        json.dump(datos, f, ensure_ascii=False, indent=4)